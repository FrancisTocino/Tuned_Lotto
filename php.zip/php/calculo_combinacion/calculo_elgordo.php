<?php 

// Me entero del nobre del Host
$nombre_host = gethostname();


// Me conecto según el caso
switch ($nombre_host) {
        case 'W10SOBREMESA':
            //VARIABLES PARA LA CONEXIÓN EN EL SOBREMESA
            $db_server = 'localhost';
            $db_user   = 'mysql_tunedlotto_user';
            $db_pass   = 'natillasdanone';
            $db_name   = 'tuned_lotto_DB';
           break;
        case 'PORTATIL-HP':
            //VARIABLES PARA LA CONEXIÓN EN EL PORTATIL HP
            $db_server = 'localhost';
            $db_user   = 'mysql_tunedlotto_user';
            $db_pass   = 'natillasdanone';
            $db_name   = 'tuned_lotto_DB';
            break;
        default :
            //VARIABLES PARA LA CONEXIÓN PARA 000WEBHOST.COM
            $db_server = 'localhost';
            $db_user   = 'id1177754_tldbuser';
            $db_pass   = 'natillasdanone';
            $db_name   = 'id1177754_tldb';
            break;
 }

//CONEXION CON SERVIDOR
        $enlace = mysqli_connect($db_server, $db_user, $db_pass, $db_name); //SERVER ,USER, PASS, DBNAME

        if (!$enlace) {
            //echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
            //echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
            //echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
            exit;
        }
        //echo '</br>[+] Conexión con la BD realizado con éxito..'; 
        
        //COMPRUEBO SI EXISTEN LAS DIFERENTES TABLAS SI NO  EXISTEN ERROR  

        $sql = 'SHOW TABLES FROM '.$db_name ;
        //echo '</br> $sql: '.$sql.'</br>';
        $result = mysqli_query($enlace,$sql);

        if (!$result) {
            //echo 'DB Error, could not list tables\n';
            //echo 'MySQL Error: ' . mysqli_error($enlace);
            exit;
        }
        //echo('[+] Listado de las Tablas de la BD');
        while ($row = mysqli_fetch_row($result)) {
            //echo 'Table: '.$row[0].'</br>';
        }

        mysqli_free_result($result);



// CONSULTA SEGUN PERIODO PASADO POR POST
$timeline = $_POST['timeline'];
//echo '---- CRITERIO PASADO POR POST $timeline: '.$timeline;

switch ($timeline) {
    case 'all':
        $consulta_principal = 'select n1, n2, n3, n4, n5 from elgordo';
        $consulta_claves = 'select n_clave from elgordo';
        break;
    case 'anio':
        $consulta_principal = 'select n1, n2, n3, n4, n5 from elgordo e where e.fecha >= date_sub(curdate(), interval 12 month)';
        $consulta_claves = 'select n_clave from elgordo e where e.fecha >= date_sub(curdate(), interval 12 month)';
        break;
    case 'six':
       $consulta_principal = 'select n1, n2, n3, n4, n5 from elgordo e where e.fecha >= date_sub(curdate(), interval 6 month)';
       $consulta_claves = 'select n_clave from elgordo e where e.fecha >= date_sub(curdate(), interval 6 month)';
        break;
    case 'three':
        $consulta_principal = 'select n1, n2, n3, n4, n5 from elgordo e where e.fecha >= date_sub(curdate(), interval 3 month)';
        $consulta_claves = 'select n_clave from elgordo e where e.fecha >= date_sub(curdate(), interval 3 month)';
        break;           
}
    
$gametabname = 'elgordo' ;
$result = mysqli_query($enlace,$consulta_principal);

// COMPRUEBO SI LA CONSULTA DEVUELVE DATOS
//$total = $result->num_rows;
//if($total==0){
    //echo '<p>NO HAY DATOS PARA ESTA CONSULTA</p>';
//}else{
    //echo '<p>HAY UN TOTAL DE '.$total.' FILAS</p>';
//}

//echo ('RESULTADOS </br>');

//Construyo la tabla DE LOS NUMEROS PRIMCIPALES con el total de los numeros extraidos
$tabla_5bolas = array();
while ($row = mysqli_fetch_object($result)) {
    //echo ($row->fecha.'||');
    //echo ($row->n1.'-'.$row->n2.'-'.$row->n3.'-'.$row->n4.'-'.$row->n5.'-'.$row->n6.'-'.$row->complementario.'</br>');
    array_push($tabla_5bolas, $row->n1, $row->n2, $row->n3, $row->n4, $row->n5);    
}

//muestro el contenido de la tabla generada
//foreach ($tabla_5bolas as &$valor){
    //echo $valor.'-';
//}
//echo '***********************'.count($tabla_primi).'***********************</br>';
    
//Libero el conjunto de resultados
$result->close();

//Ahora contruyo la tablas on todos los numeros principales
$numero_elementos =count($tabla_5bolas);
$numero_bolas = 4; //aunque son 5 bolas se empieza a contar desde 0
$tabla_5n_ganadores = array();

for ($x=0;$x<=$numero_bolas;$x++){
    $numero_aleatorio = mt_rand(0,($numero_elementos-1));
    $NumeroGanador = $tabla_5bolas[$numero_aleatorio];
    //echo($x.'numero aleatorio '.$numero_aleatorio.' Numero Ganador'.$NumeroGanador.'</br>');
    if (in_array($NumeroGanador,$tabla_5n_ganadores,true) or ($NumeroGanador==0) or ($NumeroGanador=='')){
        //echo('<p> El numero '.$tabla_5bolas[$numero_aleatorio].' está repetido o es 0 o está vacio</p>');
        $x--;
    }
    else{
        $tabla_5n_ganadores[$x] = $NumeroGanador;
    }
}


//PRESENTO LA COMBINACIÓN GANADORA
sort($tabla_5n_ganadores);
echo'Resultado: ';
for ($y=0;$y<count($tabla_5n_ganadores);$y++){
    echo ' '.$tabla_5n_ganadores[$y].' ';
}


$result2 = mysqli_query($enlace, $consulta_claves);

//Construyo la tabla DE LAS claveS con el total de los numeros extraidos
$tabla_clave = array();
while ($row = mysqli_fetch_object($result2)) {
    //echo ('-'.$row->n_clave.'</br>');
    array_push($tabla_clave, $row->n_clave); 
}

//Ahora contruyo la tablas de los numeros ganadores
$numero_elementos =count($tabla_clave);
$numero_bolas = 0; //aunque es 1 bolas se empieza a contar desde 0
$tabla_2e_ganadoras = array();

for ($x=0;$x<=$numero_bolas;$x++){
    $numero_aleatorio = mt_rand(0,($numero_elementos-1));
    $NumeroGanador= $tabla_clave[$numero_aleatorio];
    //echo($x.'numero aleatorio '.$numero_aleatorio.' Numero Ganador'.$NumeroGanador.'</br>');
    if (in_array($NumeroGanador,$tabla_2e_ganadoras,true) or ($NumeroGanador==0) or ($NumeroGanador=='')){
        //echo('<p> El numero '.$tabla_primi[$numero_aleatorio].' está repetido o es 0 o está vacio</p>');
        $x--;
    }
    else{
        $tabla_2e_ganadoras[$x]=$NumeroGanador;
    }
}


//PRESENTO LA COMBINACIÓN DE LAS DOS claveS GANADORAS
sort($tabla_2e_ganadoras);
echo'- Clave: ';
for ($y=0;$y<count($tabla_2e_ganadoras);$y++){
    echo ' '.$tabla_2e_ganadoras[$y].' ';
}


//CIERRO CONEXION CON LA BASE DE DATOS
mysqli_close($enlace);

?>

