<?php 

// Me entero del nobre del Host
$nombre_host = gethostname();

// Me conecto según el caso
switch ($nombre_host) {
		case 'W10SOBREMESA':
			//VARIABLES PARA LA CONEXIÓN EN EL SOBREMESA
			$db_server = 'localhost';
			$db_user   = 'mysql_tunedlotto_user';
			$db_pass   = 'natillasdanone';
			$db_name   = 'tuned_lotto_DB';
    	   break;
		case 'PORTATIL-HP':
			//VARIABLES PARA LA CONEXIÓN EN EL PORTATIL HP
			$db_server = 'localhost';
			$db_user   = 'mysql_tunedlotto_user';
			$db_pass   = 'natillasdanone';
			$db_name   = 'tuned_lotto_DB';
		    break;
		default :
			//VARIABLES PARA LA CONEXIÓN PARA 000WEBHOST.COM
			$db_server = 'localhost';
			$db_user   = 'id1177754_tldbuser';
			$db_pass   = 'natillasdanone';
			$db_name   = 'id1177754_tldb';
            break;
     }

//CONEXION CON SERVIDOR
    $enlace = mysqli_connect($db_server, $db_user, $db_pass, $db_name); //SERVER ,USER, PASS, DBNAME

    if (!$enlace) {
        //echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
        //echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
        //echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
        exit;
    }
    //echo '</br>[+] Conexión con la BD realizado con éxito..'; 
    
    //COMPRUEBO SI EXISTEN LAS DIFERENTES TABLAS SI NO  EXISTEN ERROR  

    $sql = 'SHOW TABLES FROM '.$db_name ;
    //echo '</br> $sql: '.$sql.'</br>';
    $result = mysqli_query($enlace,$sql);

    if (!$result) {
        //echo 'DB Error, could not list tables\n';
        //echo 'MySQL Error: ' . mysqli_error($enlace);
        exit;
    }
    //echo('[+] Listado de las Tablas de la BD');
    while ($row = mysqli_fetch_row($result)) {
        //echo 'Table: '.$row[0].'</br>';
    }

    mysqli_free_result($result);



// CONSULTA SEGUN PERIODO PASADO POR POST
$timeline = $_POST['timeline'];
//echo '---- CRITERIO PASADO POR POST $timeline: '.$timeline;

switch ($timeline) {
    case 'all':
        $consulta = 'select * from bonoloto';
        break;
    case 'anio':
        $consulta = 'select * from bonoloto b where b.fecha >= date_sub(curdate(), interval 12 month)';
        break;
    case 'six':
       $consulta = 'select * from bonoloto b where b.fecha >= date_sub(curdate(), interval 6 month)';
        break;
    case 'three':
        $consulta = 'select * from bonoloto b where b.fecha >= date_sub(curdate(), interval 3 month)';
        break;           
}
    
$gametabname = 'bonoloto' ;
$result = mysqli_query($enlace,$consulta);

// COMPRUEBO SI LA CONSULTA DEVUELVE DATOS
$total = $result->num_rows;
if($total==0){
    //echo '<p>NO HAY DATOS PARA ESTA CONSULTA</p>';
}else{
    //echo '<p>HAY UN TOTAL DE '.$total.' FILAS</p>';
}


//echo ('RESULTADOS </br>');

//Construyo la tabla con el total de los numeros extraidos
$tabla_bono = array();
while ($row = mysqli_fetch_object($result)) {
    //echo ($row->fecha.'||');
	//echo ($row->n1.'-'.$row->n2.'-'.$row->n3.'-'.$row->n4.'-'.$row->n5.'-'.$row->n6.'-'.$row->complementario.'</br>');
    array_push($tabla_bono, $row->n1, $row->n2, $row->n3, $row->n4, $row->n5, $row->n6, $row->complementario);	
}

//muestro el contenido de la tabla generada
foreach ($tabla_bono as &$valor){
    //echo $valor.'-';
}
//echo '***********************'.count($tabla_bono).'***********************</br>';
	
//Libero el conjunto de resultados
$result->close();

//Ahora contruyo la tablas de los numeros ganadores
$numero_elementos =count($tabla_bono);
$numero_bolas = 5; //aunque son 6 bolas se empieza a contar desde 5
$tabla2 = array();

for ($x=0;$x<=$numero_bolas;$x++){
	$numero_aleatorio = mt_rand(0,($numero_elementos-1));
	$NumeroGanador= $tabla_bono[$numero_aleatorio];
	//echo($x.'numero aleatorio '.$numero_aleatorio.' Numero Ganador'.$NumeroGanador.'</br>');
	if (in_array($NumeroGanador,$tabla2,true) or ($NumeroGanador==0) or ($NumeroGanador=='')){
		//echo('<p> El numero '.$tabla_bono[$numero_aleatorio].' está repetido o es 0 o está vacio</p>');
		$x--;
	}
	else{
		$tabla2[$x]=$NumeroGanador;
	}
}



//PRESENTO LA COMBINACIÓN GANADORA
sort($tabla2);
echo'Resultado: ';
for ($y=0;$y<count($tabla2);$y++){
    echo ' '.$tabla2[$y].' ';
} 



//CIERRO CONEXION CON LA BASE DE DATOS
mysqli_close($enlace);

?>
