<html>
<head>
<title>IMPORTACION_BONOLOTO.PHP</title>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css"  />
<script type="text/javascript" src="../../js/jquery-1.7.2.min.js"></script>
</head>


<?php
function combierte_fecha($cadena)
{
	echo ('<br>Estoy en la funcion de combertir la cadena: '.$cadena.' --- ');
	$partes = explode("/", $cadena);
	echo($partes[0].$partes[1].$partes[2]);
	$fech=strval($partes[2]).'-'.strval($partes[1]).'-'.strval($partes[0]);
	echo (' ------  '.$fech);
	return($fech);
}

?>

<?php
function importacion_loterias( $Nombre_Fichero ){
		$nombre_host = gethostname();

	switch ($nombre_host) {
		case 'W10SOBREMESA':
			//VARIABLES PARA LA CONEXIÓN
			$db_server = 'localhost';
			$db_user   = 'mysql_tunedlotto_user';
			$db_pass   = 'natillasdanone';
			$db_name   = 'tuned_lotto_DB';
		break;
		default:
			#//VARIABLES PARA LA CONEXIÓN
			$db_server = 'mysql.hostinger.es';
			$db_name   = 'u537219735_tldb';
			$db_user   = 'u537219735_tlus';
			$db_pass   = 'tunedlotto2017';
		break;
	}

		//CONEXION CON SERVIDOR
		$enlace = mysqli_connect($db_server, $db_user, $db_pass, $db_name); //SERVER ,USER, PASS, DBNAME

		if (!$enlace) {
			echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
			echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
			echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
			exit;
		}
		echo '</br>[+] Conexión con la BD realizado con éxito..'; 
		
		//COMPRUEBO SI EXISTEN LAS DIFERENTES TABLAS SI NO  EXISTEN ERROR  

		$sql = 'SHOW TABLES FROM '.$db_name ;
		echo '</br> $sql: '.$sql.'</br>';
		$result = mysqli_query($enlace,$sql);

		if (!$result) {
			echo 'DB Error, could not list tables\n';
			echo 'MySQL Error: ' . mysqli_error($enlace);
			exit;
		}
		echo('[+] Listado de las Tablas de la BD');
		while ($row = mysqli_fetch_row($result)) {
			echo 'Table: '.$row[0].'</br>';
		}

		mysqli_free_result($result);

		
		//CONEXIÓN CON EL FICHERO PLANO Y LECTURA

		$fnombre=$Nombre_Fichero;
		$fp=fopen($fnombre,"r") or die('<li>Fallo al abrir el fichero: '.$Nombre_Fichero.'...'. mysqli_error(). '</li><br>');
		echo '[+] FICHERO CSV ABIERTO</br>';

		//VACIAMOS LA TABLA PARA IMPORTAR LOS DATOS NUEVOS
		
		$db_query1 ='truncate bonoloto';
		$resultado = mysqli_query($enlace,$db_query1);
					if (!$resultado) {
						$message  = 'Invalid query: ' . mysqli_error() . "\n";
						$message .= 'Whole query: ' . $query;
						die($message);
					} 
		echo ('<li>[+] VACIANDO LA TABLA PARA VOLVER A POBLARLA</li><br>');


		// EMPEZAMOS A LEER Y A CONVERTIR
		
		echo ('<li>Importando ...</li><br>');
		$id_sorteo=0;
		while(!feof($fp))
		{
			//LEMEOS UNA LINEA
			$linea = fgets($fp);
			//EXTTRAEMOS LOS CAMPOS SEPRADOS POR ,
			$campos = explode(",", $linea);
			// LEO LA PRIMERA LINEA
			$fecha_bonoloto = $campos[0];
			// Y VEMOS LOS CASOS
			switch ($fecha_bonoloto)
			{
				case 'FECHA':
					echo '<li>DETECTADO CABECERA, DESCARTADADA PARA LA IMPORTACION (OK)... </li><br>';
					echo('$fecha_bonoloto: '.$fecha_bonoloto);
					break;
				case NULL:  //LINEA VACIA				
					echo '<li>DETECTADO LINEA VACIA, DESCARTADA PARA LA IMPORTAION (OK)... </li><br>';
					break;
				default: //PASO LOS VALORES PARA IMPORTAR
						// ASIGNO LAS VARIABLES
						$id_sorteo++; 
						echo ('</br>id_sorteo: '.$id_sorteo);
						$fecha_bonoloto=		combierte_fecha($campos[0]);
						$numero1=				$campos[1];
						$numero2=				$campos[2];
						$numero3=				$campos[3];
						$numero4=				$campos[4];
						$numero5=				$campos[5];
						$numero6=				$campos[6];
						$complementario=		$campos[7];
					
						$db_query1 ='insert into bonoloto values(
									"'.$id_sorteo.'",
									"'.$fecha_bonoloto.'",
									"'.$numero1.'",
									"'.$numero2.'",
									"'.$numero3.'",
									"'.$numero4.'",
									"'.$numero5.'",
									"'.$numero6.'",
									"'.$complementario.'");';
								echo '<br>'.$db_query1.'<br>';
								$resultado = mysqli_query($enlace,$db_query1);
								if (!$resultado) {
									$message  = 'QUERY INCORRECTA: ' . mysqli_error($enlace) . "\n";
									$message .= 'Query COMPLETA: ' . $db_query1;
									die($message);
								}
								echo ('<li id="detalle">Importando dato fila: '.$id_sorteo.' (OK) ...</li>');
			}

		}
		echo ('<li id="detalle">Numeros de sorteos importados: '.$id_sorteo.' (ok) ...</li>');
		echo '<br />---- Importacion finalizada correctamente-------------';
		//CIERRO EL FICHERO PLANO
		fclose($fp);
		// CIERRO LA CONEXIÓN CON LA BASE DE DATOS
		mysqli_close($enlace);

}

?>

<body> <!--INICIO - - - - - - - - - - - - - - - -->
<div >
<p><u>IMPORTANDO DATOS</u><br>
 

<?php

if (!empty($_FILES)) {
   // echo('$tempFile = '.$tempFile = $_FILES['NombreFichero']['tmp_name']);
//echo('<br />$file_name = '.$file_name = $_FILES['NombreFichero']['name']);   
   // echo('<br />$targetPath = '.$targetPath = $_SERVER['DOCUMENT_ROOT'] . $_REQUEST['folder']);
   // echo('<br />$targetFile = '.$targetFile =  str_replace('//','/',$targetPath) . $file_name);
	
	$tempFile   = $_FILES['NombreFichero']['tmp_name'];
    $file_name  = $_FILES['NombreFichero']['name'];   
    $targetPath = $_SERVER['DOCUMENT_ROOT'] . '/sugar4brain/_tunedlotto/php/importacion/';
    $targetFile =  str_replace('//','/',$targetPath) . $file_name;

	echo '</br>$targetPath: '.$targetPath; 	
	echo '</br>$targetFile: '.$targetFile;


	echo('<br />[+] Subiendo archivo al servidor...');   
	
	 
    if (move_uploaded_file($tempFile,$targetFile)){
		echo '<br />[+] El archivo se subio correctamente ... [ok]';
        $Nombre_Fichero = $_FILES['NombreFichero']['name'];
		importacion_loterias( $Nombre_Fichero );
    } else {
        echo '<br />[x] Fallo en la subida del archivo...';
		echo '<br />[x] El archivo esta corrupto o no es el correcto.';
    }
}


?>


</div>
</body>
</html>
