<?php 

// PARÁMETRO PASADO POR AJAX
$periodo = $_POST['periodo'];
// Me entero del nobre del Host
$nombre_host = gethostname();

// Me conecto según el caso
switch ($nombre_host) {
        case 'W10SOBREMESA':
            //VARIABLES PARA LA CONEXIÓN EN EL SOBREMESA
            $db_server = 'localhost';
            $db_user   = 'mysql_tunedlotto_user';
            $db_pass   = 'natillasdanone';
            $db_name   = 'tuned_lotto_DB';
           break;
        case 'PORTATIL-HP':
            //VARIABLES PARA LA CONEXIÓN EN EL PORTATIL HP
            $db_server = 'localhost';
            $db_user   = 'mysql_tunedlotto_user';
            $db_pass   = 'natillasdanone';
            $db_name   = 'tuned_lotto_DB';
            break;
        default :
            //VARIABLES PARA LA CONEXIÓN PARA 000WEBHOST.COM
            $db_server = 'localhost';
            $db_user   = 'id1177754_tldbuser';
            $db_pass   = 'natillasdanone';
            $db_name   = 'id1177754_tldb';
            break;
 }

//CONEXION CON SERVIDOR
        $enlace = mysqli_connect($db_server, $db_user, $db_pass, $db_name); //SERVER ,USER, PASS, DBNAME

        if (!$enlace) {
            //echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
            //echo "errno de depuración: " . mysqli_connect_errno() . PHP_EOL;
            //echo "error de depuración: " . mysqli_connect_error() . PHP_EOL;
            exit;
        }
        //echo '</br>[+] Conexión con la BD realizado con éxito..'; 
        
        //COMPRUEBO SI EXISTEN LAS DIFERENTES TABLAS SI NO  EXISTEN ERROR  

        $sql = 'SHOW TABLES FROM '.$db_name ;
        //echo '</br> $sql: '.$sql.'</br>';
        $result = mysqli_query($enlace,$sql);

        if (!$result) {
            //echo 'DB Error, could not list tables\n';
            //echo 'MySQL Error: ' . mysqli_error($enlace);
            exit;
        }
        //echo('[+] Listado de las Tablas de la BD');
        while ($row = mysqli_fetch_row($result)) {
            //echo 'Table: '.$row[0].'</br>';
        }

        mysqli_free_result($result);


//echo '---- CRITERIO PASADO POR POST $periodo: '.$periodo;
// CONSULTA SEGUN PERIODO PASADO POR POST



switch ($periodo) {
    case 'all':
        $consulta_estrellas = 'select estrella1, estrella2 from euromillones';
        break;
    case 'anio':
        $consulta_estrellas = 'select estrella1, estrella2 from euromillones e where e.fecha >= date_sub(curdate(), interval 12 month)';
        break;
    case 'six':
       $consulta_estrellas = 'select estrella1, estrella2 from euromillones e where e.fecha >= date_sub(curdate(), interval 6 month)';
        break;
    case 'three':
        $consulta_estrellas = 'select estrella1, estrella2 from euromillones e where e.fecha >= date_sub(curdate(), interval 3 month)';
        break;           
}
    
$gametabname = 'Numeros Estrellas' ;
$result = mysqli_query($enlace,$consulta_estrellas);

// COMPRUEBO SI LA CONSULTA DEVUELVE DATOS
//$total = $result->num_rows;
//if($total==0){
    //echo '<p>NO HAY DATOS PARA ESTA CONSULTA</p>';
//}else{
    //echo '<p>HAY UN TOTAL DE '.$total.' FILAS</p>';
//}

//Construyo la tabla con el total de los numeros extraidos
$tabla_estrellas = array();
while ($row = mysqli_fetch_object($result)) {
    //echo ($row->fecha.'||');
	//echo ($row->n1.'-'.$row->n2.'-'.$row->n3.'-'.$row->n4.'-'.$row->n5.'-'.$row->n6.'-'.$row->complementario.'</br>');
    array_push($tabla_estrellas, $row->estrella1, $row->estrella2);
}

// ORDENO LA TABLA Y LA SEPARO CON COMAS
sort($tabla_estrellas); $array2string = implode(',', $tabla_estrellas);

// FUNCION QUE ME  DA LAS VECES QUE SE REPITEN CADA ELEMENTOS
$valores = array_count_values($tabla_estrellas);

// CALCULO LA MEDIA ARITMÉTICA
$mayor = max($valores);
$menor = min($valores);
$media = ($mayor+$menor)/2;
//echo '----------------- '.$mayor;
//echo '----------------- '.$menor;

//CONTRULLO LA CADENA DE SALIDA
$cadena = '[';
foreach ($valores as $clave => $valor){
    $cadena .=  '{"x":'
              ."{$clave},"
              .'"y":'
              ."{$valor}"
              .'}';
    if ($clave < sizeof($valores))
        $cadena .= ',';
}
$cadena .= ']';


//DEVUELVO LOS DOS PARAMETROS
echo $cadena.'&'.strval($media);


//CIERRO CONEXION CON LA BASE DE DATOS
mysqli_close($enlace);

?>