<?php

//Libreria para scrapin-web
require 'simple_html_dom.php';

// Abro fichero de Log
$file = fopen("scraping.log", "a");
fwrite($file,'============================================='.PHP_EOL);


//ME CONECTO CON LA BASE DE DATOS
$conex = conexion_db();

// ME ENTERO EN QUE DIA ESTAMOS
$fecha_actual = getdate();
fwrite($file,'Día de la Semana del Sistema: '.$fecha_actual['weekday'] .PHP_EOL);
fwrite($file,PHP_EOL);
fclose($file);


// Vemos los casos
switch ($fecha_actual['weekday']) {
    case 'Monday':
        scraping_Elgordo($conex);
        break;
    case 'Tuesday':
        scraping_Bonoloto($conex); 
        break;
    case 'Wednesday':
        scraping_Bonoloto($conex);
        scraping_Euromillones($conex);
        break;
    case 'Thursday':
        scraping_Bonoloto($conex);
        break;
    case 'Friday':
        scraping_Bonoloto($conex);
        scraping_Primitiva($conex);
        break;
    case 'Saturday':
        scraping_Bonoloto($conex);
        scraping_Euromillones($conex);
        break;
    case 'Sunday':
        scraping_Bonoloto($conex);
        scraping_Primitiva($conex);
        break;

}

mysqli_close($conex);


// ------------------------------- PRIMITIVA --------------------------------------

function scraping_Primitiva($enlace){

	// Abrimos dl fichero log
	$file = fopen("scraping.log", "a");
	fwrite($file,date('d/m/Y G:i:s').'== WEBSCRAPING  DE LA PRIMITIVA =='.PHP_EOL);

	//Restar 1 dia a la fecha actual
	$hoy = date('Y-m-j');
	$nuevafecha = strtotime ( '-1 day' , strtotime ( $hoy ) ) ;
	$nuevafecha = date ( 'd/m/Y' , $nuevafecha );

	fwrite($file,date('d/m/Y G:i:s').'[+] Fecha a guardar: ' .$nuevafecha.PHP_EOL);



	//BUSQUEDA DE LOS NUMEROS DENTRO DE LA WEB DE LOTERIAS Y APUESTAS
	$url = 'http://www.loteriasyapuestas.es/es/la-primitiva';
	$html = file_get_html( $url );

	//BUSQUEDA DE LA COMBINACIÓN GANADORA
	$busqueda1 = $html->find('div.cuerpoRegionIzq li');

	$n1 = $busqueda1[0]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n1.PHP_EOL);
	$n2 = $busqueda1[1]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N2: '.$n2.PHP_EOL);
	$n3 = $busqueda1[2]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N3: '.$n3.PHP_EOL);
	$n4 = $busqueda1[3]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N4: '.$n4.PHP_EOL);
	$n5 = $busqueda1[4]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N5: '.$n5.PHP_EOL);
	$n6 = $busqueda1[5]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N6: '.$n6.PHP_EOL);

	//BUSQUEDA DEL COMPLEMENTARIO
	$busqueda3 = $html->find('div.cuerpoRegionDerecha span.bolaPeq');
	$comp = $busqueda3[0]->plaintext;
	fwrite($file,date('d/m/Y G:i:s').'[+] Complementario: '.$comp.PHP_EOL);
	fwrite($file,PHP_EOL);


	// ASIGNO LAS VARIABLES				
	$id_primitiva = NULL;
	$fecha_primitiva = strtotime ( '-1 day' , strtotime ( $hoy ) ) ; //RESTO 1 dia al la fecha actual
	$fecha_primitiva = date('Y-m-d', $fecha_primitiva) ; // Le doy Formato de Mysql
	$db_query1 ='insert into primitiva values(
				"'.$id_primitiva.'",
				"'.$fecha_primitiva.'",
				"'.$n1.'",
				"'.$n2.'",
				"'.$n3.'",
				"'.$n4.'",
				"'.$n5.'",
				"'.$n6.'",
				"'.$comp.'");';

	fwrite($file,date('d/m/Y G:i:s').' Query: '.$db_query1.PHP_EOL);

	$resultado = mysqli_query($enlace,$db_query1);
	if (!$resultado) {
		$message  = 'QUERY INCORRECTA: ' . mysqli_error($enlace) . "\n";
		$message .= 'Query COMPLETA: ' . $db_query1;
		die($message);
	}
	fwrite($file,date('d/m/Y G:i:s').'[+] Registro: '.$fecha_primitiva.' Creado en BD (OK)'.PHP_EOL);


	fclose($file);
}

// ------------------------------  BONOLOTO -----------------------------------------------------

function scraping_Bonoloto($enlace){

	// Abrimos dl fichero log
	$file = fopen("scraping.log", "a");
	fwrite($file,date('d/m/Y G:i:s').'== WEBSCRAPING  DE LA BONOLOTO =='.PHP_EOL);

	//REstar 1 dia a la fecha actual
	$hoy = date('Y-m-j');
	$nuevafecha = strtotime ( '-1 day' , strtotime ( $hoy ) ) ;
	$nuevafecha = date ( 'j/m/Y' , $nuevafecha );


	fwrite($file,date('d/m/Y G:i:s').' [+] Fecha a guardar: ' .$nuevafecha.PHP_EOL);


	//BUSQUEDA DE LOS NUMEROS DENTRO DE LA WEB DE LOTERIAS Y APUESTAS
	$url = 'http://www.loteriasyapuestas.es/es/bonoloto';
	$html = file_get_html( $url );

	//BUSQUEDA DE LA COMBINACIÓN GANADORA
	$busqueda1 = $html->find('div.cuerpoRegionIzq li');

	$n1 = $busqueda1[0]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n1.PHP_EOL);
	$n2 = $busqueda1[1]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N2: '.$n2.PHP_EOL);
	$n3 = $busqueda1[2]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N3: '.$n3.PHP_EOL);
	$n4 = $busqueda1[3]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N4: '.$n4.PHP_EOL);
	$n5 = $busqueda1[4]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N5: '.$n5.PHP_EOL);
	$n6 = $busqueda1[5]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N6: '.$n6.PHP_EOL);

	//BUSQUEDA DEL COMPLEMENTARIO
	$busqueda3 = $html->find('div.cuerpoRegionDerecha span.bolaPeq');
	$comp = $busqueda3[0]->plaintext;
	fwrite($file,date('d/m/Y G:i:s').'[+] Complementario: '.$busqueda3[0]->plaintext.PHP_EOL);
	fwrite($file,PHP_EOL);
	
	// ASIGNO LAS VARIABLES				
	$id_bonoloto = NULL;
	$fecha_bonoloto = strtotime ( '-1 day' , strtotime ( $hoy ) ) ; //RESTO 1 dia al la fecha actual
	$fecha_bonoloto = date('Y-m-d', $fecha_bonoloto) ; // Le doy Formato de Mysql
	$db_query1 ='insert into bonoloto values(
				"'.$id_bonoloto.'",
				"'.$fecha_bonoloto.'",
				"'.$n1.'",
				"'.$n2.'",
				"'.$n3.'",
				"'.$n4.'",
				"'.$n5.'",
				"'.$n6.'",
				"'.$comp.'");';

	fwrite($file,date('d/m/Y G:i:s').' Query: '.$db_query1.PHP_EOL);

	$resultado = mysqli_query($enlace,$db_query1);
	if (!$resultado) {
		$message  = 'QUERY INCORRECTA: ' . mysqli_error($enlace) . "\n";
		$message .= 'Query COMPLETA: ' . $db_query1;
		die($message);
	}
	fwrite($file,date('d/m/Y G:i:s').'[+] Registro: '.$fecha_bonoloto.' Creado en BD (OK)'.PHP_EOL);


	fclose($file);
}

// ---------------------------------------  EL GORDO ----------------------------------------

function scraping_Elgordo($enlace){

	// Abrimos dl fichero log
	$file = fopen("scraping.log", "a");
	fwrite($file,date('d/m/Y G:i:s').'== WEBSCRAPING  DEL GORDO DE LA PRIMITIVA =='.PHP_EOL);

	//REstar 1 dia a la fecha actual
	$hoy = date('Y-m-j');
	$nuevafecha = strtotime ( '-1 day' , strtotime ( $hoy ) ) ;
	$nuevafecha = date ( 'j/m/Y' , $nuevafecha );


	fwrite($file,date('d/m/Y G:i:s').' [+] Fecha a guardar: ' .$nuevafecha.PHP_EOL);


	//BUSQUEDA DE LOS NUMEROS DENTRO DE LA WEB DE LOTERIAS Y APUESTAS
	$url = 'http://www.loteriasyapuestas.es/es/gordo-primitiva';
	$html = file_get_html( $url );

	//BUSQUEDA DE LA COMBINACIÓN GANADORA
	$busqueda1 = $html->find('div.cuerpoRegionIzq li');

	$n1 = $busqueda1[0]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n1.PHP_EOL);
	$n2 = $busqueda1[1]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n2.PHP_EOL);
	$n3 = $busqueda1[2]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n3.PHP_EOL);
	$n4 = $busqueda1[3]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n4.PHP_EOL);
	$n5 = $busqueda1[4]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n5.PHP_EOL);


	//BUSQUEDA DEL NUMERO CLAVE
	$busqueda3 = $html->find('div.cuerpoRegionDerecha span.bolaPeq');
	$clave = $busqueda3[0]->plaintext;
	fwrite($file,date('d/m/Y G:i:s').'[+] Nº Clave: '.$busqueda3[0]->plaintext.PHP_EOL);
	fwrite($file,PHP_EOL);


	// ASIGNO LAS VARIABLES				
	$id_elgordo = NULL;
	$fecha_elgordo = strtotime ( '-1 day' , strtotime ( $hoy ) ) ; //RESTO 1 dia al la fecha actual
	$fecha_elgordo = date('Y-m-d', $fecha_elgordo) ; // Le doy Formato de Mysql
	$db_query1 ='insert into elgordo values(
				"'.$id_elgordo.'",
				"'.$fecha_elgordo.'",
				"'.$n1.'",
				"'.$n2.'",
				"'.$n3.'",
				"'.$n4.'",
				"'.$n5.'",
				"'.$clave.'");';

	fwrite($file,date('d/m/Y G:i:s').' Query: '.$db_query1.PHP_EOL);

	$resultado = mysqli_query($enlace,$db_query1);
	if (!$resultado) {
		$message  = 'QUERY INCORRECTA: ' . mysqli_error($enlace) . "\n";
		$message .= 'Query COMPLETA: ' . $db_query1;
		die($message);
	}
	fwrite($file,date('d/m/Y G:i:s').'[+] Registro: '.$fecha_elgordo.' Creado en BD (OK)'.PHP_EOL);


	fclose($file);

}

// ------------------------   EUROMILLONES -------------------------------------------------------
function scraping_Euromillones($enlace){

// Abrimos dl fichero log
	$file = fopen("scraping.log", "a");
	fwrite($file,date('d/m/Y G:i:s').'==WEBSCRAPING  DE EUROMILLONES=='.PHP_EOL);

	//REstar 1 dia a la fecha actual
	$hoy = date('Y-m-j');
	$nuevafecha = strtotime ( '-1 day' , strtotime ( $hoy ) ) ;
	$nuevafecha = date ( 'j/m/Y' , $nuevafecha );


	fwrite($file,date('d/m/Y G:i:s').' [+] Fecha a guardar: ' .$nuevafecha.PHP_EOL);


	//BUSQUEDA DE LOS NUMEROS DENTRO DE LA WEB DE LOTERIAS Y APUESTAS


	$url = 'http://www.loteriasyapuestas.es/es/euromillones';
	$html = file_get_html( $url );

	//BUSQUEDA DE LA COMBINACIÓN GANADORA
	$busqueda1 = $html->find('div.cuerpoRegionIzq li');

	$n1 = $busqueda1[0]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N1: '.$n1.PHP_EOL);
	$n2 = $busqueda1[1]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N2: '.$n2.PHP_EOL);
	$n3 = $busqueda1[2]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N3: '.$n3.PHP_EOL);
	$n4 = $busqueda1[3]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N4: '.$n4.PHP_EOL);
	$n5 = $busqueda1[4]->plaintext; fwrite($file,date('d/m/Y G:i:s').'[+] N5: '.$n5.PHP_EOL);


	//BUSQUEDA DE LOS NUEROS ESTRELLAS
	$busqueda3 = $html->find('div.cuerpoRegionDerecha li');
	$estrella1 = $busqueda3[0]->plaintext;
	$estrella2 = $busqueda3[1]->plaintext;

	fwrite($file,date('d/m/Y G:i:s').'[+] Nº Clave: '.$estrella1.PHP_EOL);
	fwrite($file,date('d/m/Y G:i:s').'[+] Nº Clave: '.$estrella2.PHP_EOL);
	fwrite($file,PHP_EOL);

	// ASIGNO LAS VARIABLES				
	$id_euromillones = NULL;
	$fecha_euromillones = strtotime ( '-1 day' , strtotime ( $hoy ) ) ; //RESTO 1 dia al la fecha actual
	$fecha_euromillones = date('Y-m-d', $fecha_euromillones) ; // Le doy Formato de Mysql
	$db_query1 ='insert into euromillones values(
				"'.$id_euromillones.'",
				"'.$fecha_euromillones.'",
				"'.$n1.'",
				"'.$n2.'",
				"'.$n3.'",
				"'.$n4.'",
				"'.$n5.'",
				"'.$estrella1.'",
				"'.$estrella2.'");';

	fwrite($file,date('d/m/Y G:i:s').' Query: '.$db_query1.PHP_EOL);

	$resultado = mysqli_query($enlace,$db_query1);
	if (!$resultado) {
		$message  = 'QUERY INCORRECTA: ' . mysqli_error($enlace) . "\n";
		$message .= 'Query COMPLETA: ' . $db_query1;
		fwrite($file,date('d/m/Y G:i:s').'[X] '.$message.PHP_EOL);
		die($message);
	}
	fwrite($file,date('d/m/Y G:i:s').'[+] Registro: '.$fecha_euromillones.' Creado en BD (OK)'.PHP_EOL);



fclose($file);

}


function conexion_db(){



	// Abrimos dl fichero log
	$file = fopen("scraping.log", "a");

	// Averiguo el nombre del HOST
	$nombre_host = gethostname();

	switch ($nombre_host) {
		case 'W10SOBREMESA':
			//VARIABLES PARA LA CONEXIÓN
			$db_server = 'localhost';
			$db_user   = 'mysql_tunedlotto_user';
			$db_pass   = 'natillasdanone';
			$db_name   = 'tuned_lotto_DB';
    	   break;
		case 'PORTATIL-HP':
			//VARIABLES PARA LA CONEXIÓN
			$db_server = 'localhost';
			$db_user   = 'mysql_tunedlotto_user';
			$db_pass   = 'natillasdanone';
			$db_name   = 'tuned_lotto_DB';
		    break;
		case '12139.us-imm-node2c.000webhost.io':
			//VARIABLES PARA LA CONEXIÓN PARA 000WEBHOST.COM
			$db_server = 'localhost';
			$db_user   = 'id1177754_tldbuser';
			$db_pass   = 'natillasdanone';
			$db_name   = 'id1177754_tldb';
            break;
		default:
			//VARIABLES PARA LA CONEXIÓN DE HOSTINGER
			$db_server = 'mysql.hostinger.es';
			$db_name   = 'u537219735_tldb';
			$db_user   = 'u537219735_tlus';
			$db_pass   = 'tunedlotto2017';
		    break;
	}


	//CONEXION CON SERVIDOR
	$enlace = mysqli_connect($db_server, $db_user, $db_pass, $db_name); //SERVER ,USER, PASS, DBNAME

	if (!$enlace) {
		fwrite($file,date('d/m/Y G:i:s').' [x] Error: No se pudo conectar a MySQL.'. PHP_EOL);
		fwrite($file,date('d/m/Y G:i:s').' [x] errno de depuración: ' . mysqli_connect_errno() . PHP_EOL);
		fwrite($file,date('d/m/Y G:i:s').' [x] error de depuración: ' . mysqli_connect_error() . PHP_EOL);
		exit;
	}
	fwrite($file,date('d/m/Y G:i:s').' [+] Conexión con la BD realizado con éxito..'.PHP_EOL); 
	

	//COMPRUEBO SI EXISTEN LAS DIFERENTES TABLAS SI NO  EXISTEN ERROR  
	$sql = 'SHOW TABLES FROM '.$db_name ;
	fwrite($file,date('d/m/Y G:i:s').' [+] $Cadena sql: '.$sql.PHP_EOL);
	$result = mysqli_query($enlace,$sql);

	if (!$result) {
		fwrite($file,date('d/m/Y G:i:s').' [x] DB Error, could not list tables\n'.PHP_EOL);
		fwrite($file,date('d/m/Y G:i:s').' [x] MySQL Error: ' . mysqli_error($enlace).PHP_EOL);
		exit;
	}
	fwrite($file,date('d/m/Y G:i:s').'[+] Listado de las Tablas de la BD'.PHP_EOL);
	while ($row = mysqli_fetch_row($result)) {
		fwrite($file,date('d/m/Y G:i:s').'->Table: '.$row[0].PHP_EOL);
	}

	mysqli_free_result($result);

	fclose($file);

	return($enlace);

}


?>